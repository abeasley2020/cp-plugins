/* SCORM 1.2 completion wrapper. Injected at packaging time only.
   Marks the SCO incomplete on open, completed after the learner reaches the
   end of the page AND stays MIN_DWELL_SECONDS. Reports no score. */
(function () {
  "use strict";
  var MIN_DWELL_SECONDS = 45;
  var SCROLL_SLACK_PX = 120;
  var api = null, live = false, marked = false, dwell = false, end = false;
  function findAPI(win) {
    var depth = 0;
    while (win && depth < 10) {
      if (win.API) { return win.API; }
      if (!win.parent || win.parent === win) { break; }
      win = win.parent; depth += 1;
    }
    return null;
  }
  function getAPI() {
    var f = null;
    try { f = findAPI(window); } catch (e) { f = null; }
    if (!f && window.opener) { try { f = findAPI(window.opener); } catch (e2) { f = null; } }
    return f;
  }
  function init() {
    api = getAPI();
    if (!api) { return false; }
    try { live = String(api.LMSInitialize("")) === "true"; } catch (e) { live = false; }
    if (!live) { return false; }
    try {
      var s = api.LMSGetValue("cmi.core.lesson_status");
      if (!s || s === "not attempted") { api.LMSSetValue("cmi.core.lesson_status", "incomplete"); api.LMSCommit(""); }
      else if (s === "completed" || s === "passed") { marked = true; }
    } catch (e3) {}
    return true;
  }
  function complete() {
    if (!live || marked) { return; }
    try { api.LMSSetValue("cmi.core.lesson_status", "completed"); api.LMSCommit(""); marked = true; } catch (e) {}
  }
  function check() { if (dwell && end) { complete(); } }
  function atEnd() {
    var d = document.documentElement, b = document.body;
    var h = Math.max(b.scrollHeight, d.scrollHeight, b.offsetHeight, d.offsetHeight);
    var v = window.innerHeight || d.clientHeight;
    var y = window.pageYOffset || d.scrollTop || b.scrollTop || 0;
    if (h <= v + SCROLL_SLACK_PX) { return true; }
    return (y + v) >= (h - SCROLL_SLACK_PX);
  }
  function onScroll() { if (!end && atEnd()) { end = true; check(); } }
  function teardown() { if (!live) { return; } try { api.LMSCommit(""); api.LMSFinish(""); } catch (e) {} live = false; }
  if (!init()) { return; }
  window.setTimeout(function () { dwell = true; check(); }, MIN_DWELL_SECONDS * 1000);
  window.addEventListener("scroll", onScroll, false);
  window.addEventListener("resize", onScroll, false);
  window.addEventListener("load", onScroll, false);
  window.addEventListener("pagehide", teardown, false);
  window.addEventListener("unload", teardown, false);
  onScroll();
})();
